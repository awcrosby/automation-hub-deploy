echo 'Creating and running openshift job...'
echo 'apiVersion: batch/v1
kind: Job
metadata:
  name: quay-ans-test
spec:
  parallelism: 1
  completions: 1
  activeDeadlineSeconds: 1800 
  backoffLimit: 0
  template:
    metadata:
      name: quay-ans-test-metadata
    spec:
      # hostNetwork: true  # causes?: error: timed out waiting for the condition
      containers:
      - name: quay-ans-test-container
        image: quay.io/awcrosby/ans-test-with-archive
        # ports:
        #   - containerPort: 5001
        #     hostPort: 5001
        # securityContext:
        #   privileged: true
        # env:
        #   - name: MYVAR1
        #     value: value1
        command: ["/bin/sh","-c"]
        # args: ["pwd; cd /ansible_collections; curl https://raw.githubusercontent.com/ansible/galaxy-importer/master/docker/ansible-test/entrypoint.sh --output test.txt; pwd; ls"]
        args: ["pwd; cd /ansible_collections; curl http://e8101669.ngrok.io/api/automation-hub/v3/artifacts/collections/awcrosby.collection_test.1.0.11 --output test.txt; pwd; ls"]
      #   volumeMounts:
      #   - name: log
      #     mountPath: /log
      #     readOnly: true
      # volumes:
      # - name: log
      #   hostPath:
      #     path: /var/log/
      restartPolicy: Never
' >> job.yaml
oc create -f job.yaml
rm job.yaml

sleep 5

echo 'Getting logs from job'
oc logs jobs/quay-ans-test -f

echo 'Deleting files...'
oc delete job/quay-ans-test
