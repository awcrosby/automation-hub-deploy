#What is a collection?

A collection is a distribution format for delivering all types of Ansible Content.

The standard format for a collection looks something like this:

```
demo/
├── README.md
├── galaxy.yml
├── plugins
│   └── modules
│       └── real_facts.py
└── roles
    └── factoid
        ├── README.md
        ├── meta
        │   └── main.yaml
        └── tasks
            └── main.yml
```
