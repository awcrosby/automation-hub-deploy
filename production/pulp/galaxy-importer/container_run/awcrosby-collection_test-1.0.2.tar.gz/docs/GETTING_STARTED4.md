## This is getting started doc
With good details
