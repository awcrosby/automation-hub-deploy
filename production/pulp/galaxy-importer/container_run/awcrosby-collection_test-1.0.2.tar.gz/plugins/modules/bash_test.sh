#!/bin/bash
cat test.txt
